
(function() {
  // Root init function
  colorSubheadings();

  var sidebar = document.querySelector('.chapter-sidebar');
  if (sidebar) {
    initializeChapterSidebar();

    var sidebar = document.querySelector('.chapter-sidebar');
    var header = document.querySelector('.page-header');
    var headerBottom = header.getBoundingClientRect().width;

    var content= document.querySelector('.content');    // .page-header
    var contentBottom = content.getBoundingClientRect().width;  //.bottom

    if ((contentBottom >= 1660) || (headerBottom >= 1660)) {   
      // Make it sticky 
      addClass(sidebar, 'chapter-sidebar--sticky');
    } else {
      // Make it not stick
      removeClass(sidebar, 'chapter-sidebar--sticky');
    }
  }

  initializeMobileNav();
  buildChapterNav();
  initializeBackToTop();
  initializeSidebarResize();
})();


function colorSubheadings() {
  // Replace subheading background colors
  var redStart = 205;
  var greenStart = 205;
  var blueStart = 205;
  var redEnd = 249;
  var greenEnd = 250;
  var blueEnd = 251;

  var redDiff = redEnd - redStart;
  var greenDiff = greenEnd - greenStart;
  var blueDiff = blueEnd - blueStart;

  var page = document.querySelector('.page');
  var pageHeight = page.offsetHeight;

  var subheadings = document.querySelectorAll('.subheading');
  for(var i = 0; i < subheadings.length; i++){
    // Get the position relative to .page
    var span = subheadings[i].querySelector('span');
    var factor = span.offsetTop / pageHeight;

    var r = Math.floor(redDiff * factor + redStart);
    var g = Math.floor(greenDiff * factor + greenStart);
    var b = Math.floor(blueDiff * factor + blueStart);
    var color = 'rgb('+r+','+g+','+b+')';

    // Color background based on position
    span.style.backgroundColor = color;
    span.style.boxShadow = '11px 0 0 '+color+', -13px 0 0 '+color;
  }
}

function initializeChapterSidebar() {

  function onScrollEventHandler(ev) {
    // --- Sticky Sidebar ---

    // var sidebar = document.querySelector('.chapter-sidebar');
    // var header = document.querySelector('.content');    // .page-header
    // var headerBottom = header.getBoundingClientRect().bottom;  //.bottom

    // if (headerBottom >= 42) {   
    //   // Make it sticky 
    //   addClass(sidebar, 'chapter-sidebar--sticky');
    // } else {
    //   // Make it not stick
    //   removeClass(sidebar, 'chapter-sidebar--sticky');
    // }


    // --- Sidebar Link Highlight ---

    // Reset the highlighted sidebar link(s)
    var highlightedLinks = document.querySelectorAll('.sidebar__link--highlight');
    for (var i=0; i<highlightedLinks.length; i++) {
      removeClass(highlightedLinks[i], 'sidebar__link--highlight');
    }

    var headings = document.querySelectorAll('.subheading__heading');
    for (var i=headings.length-1; i>=0; i--) {
      var heading = headings[i];
      var rect = heading.getBoundingClientRect();

      // -40 is for .subheading top padding
      if (rect.top < window.innerHeight - window.innerHeight/2 - 40) {
        // Go find the matching element in the sidebar and highlight it
        // Get the first visible one (need to subtract window height)
        var headingID = heading.getAttribute('id');
        var sidebarLinks = document.querySelectorAll('.sidebar__link');
        for (var j=0; j<sidebarLinks.length; j++) {
          var sidebarLink = sidebarLinks[j];
          var href = sidebarLink.getAttribute('href').substring(1);
          if (href === headingID) {
            // Found it
            addClass(sidebarLink, 'sidebar__link--highlight');
          }
        }
        break;
      }
    }
  }

  if(window.addEventListener) {
    window.addEventListener('scroll', throttle(onScrollEventHandler, 300), false);
  } else if (window.attachEvent) {
    window.attachEvent('onscroll', throttle(onScrollEventHandler, 300));
  }
}

// Resize Event
let timer = null;
let delay = 300;
window.addEventListener('resize', function(){
  this.clearTimeout(timer);

  timer = setTimeout(() => {
    var sidebar = document.querySelector('.chapter-sidebar');
    var header = document.querySelector('.page-header');
    var headerBottom = header.getBoundingClientRect().width;

    var content= document.querySelector('.content');    // .page-header
    var contentBottom = content.getBoundingClientRect().width;  //.bottom

    if ((contentBottom >= 1660) || (headerBottom >= 1660)) {   
      // Make it sticky 
      addClass(sidebar, 'chapter-sidebar--sticky');
    } else {
      // Make it not stick
      removeClass(sidebar, 'chapter-sidebar--sticky');
    }
  }, delay);
});
// End Resize Event

// --- Utils ---
function throttle (callback, limit) {
  var wait = false;
  return function () {
    if (!wait) {
      callback.call();
      wait = true;
      setTimeout(function () {
        wait = false;
        }, limit);
      }
    }
}

function addClass(element, className) {
  if (element.classList) {
    element.classList.add(className);
  } else {
    // Don't add more than once
    if (element.className.indexOf(className) === -1) {
      element.className += ' ' + className;
    }
  }
}

function removeClass(element, className) {
  if (element.classList) {
    element.classList.remove(className);
  } else {
    element.className = element.className.replace(new RegExp('(^|\\b)' + className.split(' ').join('|') + '(\\b|$)', 'gi'), ' ');
  }
}

// --- Mobile Nav Toggle ---
function initializeMobileNav() {
  var toggle = document.querySelector('.mobile-nav-toggle');
  var sidebar = document.querySelector('.chapter-sidebar');
  if (!toggle || !sidebar) {
    return;
  }

  var backdrop = document.createElement('div');
  backdrop.className = 'sidebar-backdrop';
  document.body.appendChild(backdrop);

  function closeMobileNav() {
    removeClass(sidebar, 'chapter-sidebar--open');
    removeClass(backdrop, 'sidebar-backdrop--visible');
    toggle.setAttribute('aria-expanded', 'false');
  }

  function openMobileNav() {
    addClass(sidebar, 'chapter-sidebar--open');
    addClass(backdrop, 'sidebar-backdrop--visible');
    toggle.setAttribute('aria-expanded', 'true');
  }

  toggle.addEventListener('click', function() {
    if (sidebar.className.indexOf('chapter-sidebar--open') === -1) {
      openMobileNav();
    } else {
      closeMobileNav();
    }
  });

  backdrop.addEventListener('click', closeMobileNav);

  var sidebarLinks = sidebar.querySelectorAll('.sidebar__link');
  for (var i = 0; i < sidebarLinks.length; i++) {
    sidebarLinks[i].addEventListener('click', closeMobileNav);
  }
}
// --- End Mobile Nav Toggle ---

// --- Chapter Prev/Next Nav ---
function buildChapterNav() {
  var headings = document.querySelectorAll('.subheading__heading[id]');
  for (var i = 0; i < headings.length; i++) {
    var heading = headings[i];
    var subheading = heading.closest('.subheading');
    if (!subheading) {
      continue;
    }

    var nav = document.createElement('div');
    nav.className = 'chapter-nav';

    if (i > 0) {
      var prevHeading = headings[i - 1];
      var prevLink = document.createElement('a');
      prevLink.className = 'chapter-nav__link chapter-nav__link--prev';
      prevLink.href = '#' + prevHeading.id;
      prevLink.textContent = '← ' + prevHeading.textContent.trim();
      nav.appendChild(prevLink);
    }

    if (i < headings.length - 1) {
      var nextHeading = headings[i + 1];
      var nextLink = document.createElement('a');
      nextLink.className = 'chapter-nav__link chapter-nav__link--next';
      nextLink.href = '#' + nextHeading.id;
      nextLink.textContent = nextHeading.textContent.trim() + ' →';
      nav.appendChild(nextLink);
    }

    subheading.insertAdjacentElement('afterend', nav);
  }
}
// --- End Chapter Prev/Next Nav ---

// --- Sidebar Resize ---
function initializeSidebarResize() {
  var handle = document.querySelector('.chapter-sidebar__resize-handle');
  if (!handle) {
    return;
  }

  var MIN_WIDTH = 180;
  var MAX_WIDTH = 480;
  var STORAGE_KEY = 'manualSidebarWidth';

  var savedWidth = localStorage.getItem(STORAGE_KEY);
  if (savedWidth) {
    document.documentElement.style.setProperty('--sidebar-width', savedWidth + 'px');
  }

  var dragging = false;

  handle.addEventListener('mousedown', function(ev) {
    dragging = true;
    addClass(handle, 'is-dragging');
    document.body.style.userSelect = 'none';
    document.body.style.cursor = 'ew-resize';
    ev.preventDefault();
  });

  document.addEventListener('mousemove', function(ev) {
    if (!dragging) {
      return;
    }
    var width = ev.clientX;
    if (width < MIN_WIDTH) {
      width = MIN_WIDTH;
    } else if (width > MAX_WIDTH) {
      width = MAX_WIDTH;
    }
    document.documentElement.style.setProperty('--sidebar-width', width + 'px');
  });

  document.addEventListener('mouseup', function() {
    if (!dragging) {
      return;
    }
    dragging = false;
    removeClass(handle, 'is-dragging');
    document.body.style.userSelect = '';
    document.body.style.cursor = '';
    var currentWidth = getComputedStyle(document.documentElement).getPropertyValue('--sidebar-width');
    localStorage.setItem(STORAGE_KEY, parseInt(currentWidth, 10));
  });
}
// --- End Sidebar Resize ---

// --- Back to Top ---
function initializeBackToTop() {
  var button = document.createElement('button');
  button.className = 'back-to-top';
  button.setAttribute('aria-label', 'Back to top');
  button.textContent = '↑';
  document.body.appendChild(button);

  button.addEventListener('click', function() {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  });

  window.addEventListener('scroll', throttle(function() {
    if (window.scrollY > 400) {
      addClass(button, 'back-to-top--visible');
    } else {
      removeClass(button, 'back-to-top--visible');
    }
  }, 300), false);
}
// --- End Back to Top ---

function getHeight(originalElement) {
  // Calculate height based on *cloned* element to avoid messing up styles
  var element = originalElement.cloneNode(true);
  originalElement.parentNode.replaceChild(element, originalElement);

  // Set styles to make sure it's going to calculate the correct height
  element.style.display = 'block';
  element.style.visibility = 'hidden';   
  element.style.height = 'auto';

  var desiredHeight = element.offsetHeight;

  // Replace the cloned element with the original one
  element.parentNode.replaceChild(originalElement, element);

  return desiredHeight;
}

function slideDown(originalElement) {
  var desiredHeight = getHeight(originalElement);
  setTimeout(function(timestamp) {
    originalElement.style.height = desiredHeight + 'px';
  }, 1);
}

function slideUp(originalElement) {
  // Can't transition from an auto height, so make sure it's explicit
  var currentHeight = getHeight(originalElement);
  originalElement.style.height = currentHeight + 'px';
  setTimeout(function(timestamp) {
    originalElement.style.height = 0 + 'px';
  }, 1);
}

function getParameterByName(name, url) {
  if (!url) {
    url = window.location.href;
  }
  name = name.replace(/[\[\]]/g, "\\$&");
  var regex = new RegExp("[?&]" + name + "(=([^&#]*)|&|#|$)"),
  results = regex.exec(url);
  if (!results) return null;
  if (!results[2]) return '';
  return decodeURIComponent(results[2].replace(/\+/g, " "));
}

