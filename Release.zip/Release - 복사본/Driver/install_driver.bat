pushd "%~dp0"

%SystemRoot%\System32\InfDefaultInstall.exe ".\USB_Driver.inf"